source $(echo ~/Shell)/config.sh
for host in "${hosts[@]}";do
    sshpass -p $passwd ssh $host 'bash -s' < $(echo ~/Shell)/ssh_one_to_all.sh
done