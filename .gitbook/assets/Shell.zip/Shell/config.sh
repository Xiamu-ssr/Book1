#config.sh
hosts=(
bgm
bgs1
bgs2
bgs3
)
passwd="1009"