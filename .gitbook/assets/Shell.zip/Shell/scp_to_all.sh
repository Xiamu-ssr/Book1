#!/bin/bash
help="2 arguments:\n    first is PATH where scp from\n    second is PATH where scp to\n    first could both dir and file"

# 判断输入参数是否为2个
if [ $# -ne 2 ]; then
    echo -e $help
    exit 1
fi

# 获取输入参数
input=$1
output=$2

# 判断输入路径是否存在
if [ ! -e "$input" ]; then
    echo -e $help
    exit 1
fi

source $(echo ~/Shell)/config.sh
# 循环传输文件
for host in "${hosts[@]}"; do
    # 判断输入路径是文件还是目录
    if [ -d "$input" ]; then
        sshpass -p $passwd scp -o StrictHostKeyChecking=no -r "$input" $host:"$output"
    else
        sshpass -p $passwd scp -o StrictHostKeyChecking=no "$input" $host:"$output"
    fi
done