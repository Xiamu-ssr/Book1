source $(echo ~/Shell)/config.sh
# 判断输入路径是否存在
if [ ! -e $(echo ~/.ssh/id_rsa) ]; then
    ssh-keygen -t rsa -N "" -f $(echo ~/.ssh/id_rsa)
else
    echo "find "$(echo ~/.ssh/id_rsa)
fi

for host in "${hosts[@]}"; do
    #sshpass明文跳过手动输入密码,关闭ssh-copy-id指纹验证
    sshpass -p $passwd ssh-copy-id -o StrictHostKeyChecking=no -i "$host"
done